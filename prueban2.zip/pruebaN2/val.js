$.validator.addMethod("terminapor", function(value,element,parametro){

    if(value.endsWith(parametro)){
        return true;
    }
    return false;
}, "Debe ternimar por {0}")


$("#form_cotizacion").validate({
    rules:{
        nombre: {
            required:true,
            minlength: 3,
            maxlength: 30
            
        },
        modelo_vehiculo:{
            required:true,
            minlength: 3,
            maxlength: 40
        },
        comentario:{
            minlength: 3,
            maxlength: 50
        }

    }
})


$("#enviar").click(function(){
    if($("#form_cotizacion").valid()=false){
        return;
    }
    let rut = $("#rut").val()
    let nombre = $("#nombre").val()
    let telefono = $("#telefono").val()
    let email = $("#email").val()
    let tipo_lavado =$("#tip_lav").is(":select")
    let comentario =$("#comentario")
    let modelo_vehiculo=$("#model_vehi")
    
})